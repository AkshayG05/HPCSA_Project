# CDAC_HPCSA_PROJECT
In this project, the CI/CD pipeline is used to automate the deployment process. Also deploying built application to target environment cloud server or container, for provisioning, configuration, and containerization using Docker. HPC Docker xCAT image deployment can be used in future enhancement.
